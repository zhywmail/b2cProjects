function submitForm(msg){
    if(msg=="ok"){
        alert("添加成功");
    }else {
        alert(msg);
    }

}