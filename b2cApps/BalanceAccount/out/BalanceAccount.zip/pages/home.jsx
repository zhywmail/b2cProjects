(function () {
//#import Util.js

    var merchantId = $.params["m"];

    response.sendRedirect("balanceList.jsx?m="+merchantId);

})();

