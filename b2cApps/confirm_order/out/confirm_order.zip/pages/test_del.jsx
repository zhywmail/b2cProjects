//#import doT.min.js
//#import pigeon.js
//#import $OrderConfirm:services/OrderConfirmService.jsx
//#import Util.js

(function () {
    OrderConfirmService.clearCondition();

})();