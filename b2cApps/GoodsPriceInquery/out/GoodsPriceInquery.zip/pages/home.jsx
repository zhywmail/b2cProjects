(function () {
//#import Util.js

    var merchantId = $.params["m"];

    response.sendRedirect("GoodsPriceList.jsx?m="+merchantId);

})();

